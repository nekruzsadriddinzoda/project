<footer class="main"
	style="text-align: center;">
	Need help?  <a href="http://support.creativeitem.com" target="_blank" style="text-decoration:underline;">Contact support</a>
</footer>
